
<header>
    <div class="header-top">
        <a href="./todo_index.php">WEEKLY</a>
        <a href="./todo_insert.php">ADD</a>
        <a href="./todo_delete.php?no=<?php echo $no; ?>&page=<?php echo $page; ?>">DELETE</a>
    </div>
    <h1>TO DO LIST</h1>
</header>