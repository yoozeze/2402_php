
<header>
    <div class="header-top">
        <a href="./todo_index.php">WEEKLY</a>
        <a href="./todo_insert.php?no=<?php echo $no; ?>&page=<?php echo $page; ?>">ADD</a>
        <a href="./todo_delete.php">DELETE</a>
    </div>
    <h1>TO DO LIST</h1>
</header>